.class public final synthetic Lcom/ahsim/demulation/RetroTvCompositor$$ExternalSyntheticLambda0;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnLayoutChangeListener;


# instance fields
.field public final synthetic f$0:Lcom/ahsim/demulation/RetroTvCompositor;


# direct methods
.method public synthetic constructor <init>(Lcom/ahsim/demulation/RetroTvCompositor;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/ahsim/demulation/RetroTvCompositor$$ExternalSyntheticLambda0;->f$0:Lcom/ahsim/demulation/RetroTvCompositor;

    return-void
.end method


# virtual methods
.method public final onLayoutChange(Landroid/view/View;IIIIIIII)V
    .locals 10

    .line 0
    iget-object v0, p0, Lcom/ahsim/demulation/RetroTvCompositor$$ExternalSyntheticLambda0;->f$0:Lcom/ahsim/demulation/RetroTvCompositor;

    move-object v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move v5, p5

    move/from16 v6, p6

    move/from16 v7, p7

    move/from16 v8, p8

    move/from16 v9, p9

    invoke-static/range {v0 .. v9}, Lcom/ahsim/demulation/RetroTvCompositor;->$r8$lambda$sN9vJx6kjE3GnuuHW8LShpjpCPM(Lcom/ahsim/demulation/RetroTvCompositor;Landroid/view/View;IIIIIIII)V

    return-void
.end method
