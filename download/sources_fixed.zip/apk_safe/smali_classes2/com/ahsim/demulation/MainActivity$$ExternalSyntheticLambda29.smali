.class public final synthetic Lcom/ahsim/demulation/MainActivity$$ExternalSyntheticLambda29;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/util/Comparator;


# direct methods
.method public synthetic constructor <init>()V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final compare(Ljava/lang/Object;Ljava/lang/Object;)I
    .locals 0

    .line 0
    check-cast p1, Lcom/ahsim/demulation/MainActivity$ManualSaveInfo;

    check-cast p2, Lcom/ahsim/demulation/MainActivity$ManualSaveInfo;

    invoke-static {p1, p2}, Lcom/ahsim/demulation/MainActivity;->lambda$listManualSaves$39(Lcom/ahsim/demulation/MainActivity$ManualSaveInfo;Lcom/ahsim/demulation/MainActivity$ManualSaveInfo;)I

    move-result p1

    return p1
.end method
