.class public final synthetic Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Lcom/ahsim/demulation/LauncherActivity;

.field public final synthetic f$1:Lcom/ahsim/demulation/RazorCampaignNativeSession;

.field public final synthetic f$2:I

.field public final synthetic f$3:I

.field public final synthetic f$4:Lcom/ahsim/demulation/RazorCampaignSessionGuard$Snapshot;


# direct methods
.method public synthetic constructor <init>(Lcom/ahsim/demulation/LauncherActivity;Lcom/ahsim/demulation/RazorCampaignNativeSession;IILcom/ahsim/demulation/RazorCampaignSessionGuard$Snapshot;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;->f$0:Lcom/ahsim/demulation/LauncherActivity;

    iput-object p2, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;->f$1:Lcom/ahsim/demulation/RazorCampaignNativeSession;

    iput p3, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;->f$2:I

    iput p4, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;->f$3:I

    iput-object p5, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;->f$4:Lcom/ahsim/demulation/RazorCampaignSessionGuard$Snapshot;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 5

    .line 0
    iget-object v0, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;->f$0:Lcom/ahsim/demulation/LauncherActivity;

    iget-object v1, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;->f$1:Lcom/ahsim/demulation/RazorCampaignNativeSession;

    iget v2, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;->f$2:I

    iget v3, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;->f$3:I

    iget-object v4, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda64;->f$4:Lcom/ahsim/demulation/RazorCampaignSessionGuard$Snapshot;

    invoke-static {v0, v1, v2, v3, v4}, Lcom/ahsim/demulation/LauncherActivity;->$r8$lambda$eTcX-9fy-HU0E7EVyolacputyEA(Lcom/ahsim/demulation/LauncherActivity;Lcom/ahsim/demulation/RazorCampaignNativeSession;IILcom/ahsim/demulation/RazorCampaignSessionGuard$Snapshot;)V

    return-void
.end method
