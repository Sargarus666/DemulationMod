.class public final Lcom/ahsim/demulation/DuneSegaHud;
.super Ljava/lang/Object;
.source "DuneSegaHud.java"


# static fields
.field private static cachedTypeface:Landroid/graphics/Typeface;


# direct methods
.method private constructor <init>()V
    .locals 0

    .line 13
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method

.method public static aboveRadarRect(Landroid/graphics/RectF;FILandroid/graphics/RectF;)V
    .locals 5

    .line 41
    if-eqz p0, :cond_1

    invoke-virtual {p0}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto :goto_0

    .line 45
    :cond_0
    const/high16 v0, 0x41d00000    # 26.0f

    mul-float/2addr v0, p1

    invoke-virtual {p0}, Landroid/graphics/RectF;->width()F

    move-result v1

    const v2, 0x3ee147ae    # 0.44f

    mul-float/2addr v1, v2

    invoke-static {v0, v1}, Ljava/lang/Math;->min(FF)F

    move-result v0

    .line 46
    const/high16 v1, 0x40a00000    # 5.0f

    mul-float/2addr v1, p1

    .line 47
    const/high16 v2, 0x40000000    # 2.0f

    mul-float/2addr v2, v0

    add-float/2addr v2, v1

    .line 48
    invoke-virtual {p0}, Landroid/graphics/RectF;->centerX()F

    move-result v3

    .line 49
    const/high16 v4, 0x3f000000    # 0.5f

    mul-float/2addr v2, v4

    sub-float/2addr v3, v2

    int-to-float p2, p2

    add-float/2addr v1, v0

    mul-float/2addr p2, v1

    add-float/2addr v3, p2

    .line 50
    iget p0, p0, Landroid/graphics/RectF;->top:F

    const/high16 p2, 0x40400000    # 3.0f

    mul-float/2addr p1, p2

    sub-float/2addr p0, p1

    .line 51
    sub-float p1, p0, v0

    add-float/2addr v0, v3

    invoke-virtual {p3, v3, p1, v0, p0}, Landroid/graphics/RectF;->set(FFFF)V

    .line 52
    return-void

    .line 42
    :cond_1
    :goto_0
    invoke-virtual {p3}, Landroid/graphics/RectF;->setEmpty()V

    .line 43
    return-void
.end method

.method public static applyFont(Landroid/graphics/Paint;)V
    .locals 1

    if-nez p0, :cond_0

    return-void

    :cond_0
    sget-object v0, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    invoke-virtual {p0, v0}, Landroid/graphics/Paint;->setTypeface(Landroid/graphics/Typeface;)Landroid/graphics/Typeface;

    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroid/graphics/Paint;->setFakeBoldText(Z)V

    return-void
.end method

.method private static drawBaseIcon(Landroid/graphics/Canvas;Landroid/graphics/RectF;FLandroid/graphics/Paint;)V
    .locals 16

    .line 120
    move-object/from16 v6, p3

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/RectF;->centerX()F

    move-result v7

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/RectF;->centerY()F

    move-result v0

    const/high16 v1, 0x3f000000    # 0.5f

    mul-float v1, v1, p2

    add-float v8, v0, v1

    .line 121
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 122
    const v0, 0x3f866666    # 1.05f

    mul-float v0, v0, p2

    const/high16 v1, 0x3f800000    # 1.0f

    invoke-static {v1, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 123
    const/16 v0, -0x1852

    invoke-virtual {v6, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 124
    const v0, 0x40b9999a    # 5.8f

    mul-float v0, v0, p2

    sub-float v1, v7, v0

    const v2, 0x3e99999a    # 0.3f

    mul-float v2, v2, p2

    sub-float v9, v8, v2

    add-float v10, v7, v0

    const/high16 v0, 0x40a00000    # 5.0f

    mul-float v0, v0, p2

    add-float v11, v8, v0

    move-object/from16 v0, p0

    move v2, v9

    move v3, v10

    move v4, v11

    move-object/from16 v5, p3

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 125
    const/high16 v0, 0x40d00000    # 6.5f

    mul-float v12, p2, v0

    sub-float v1, v7, v12

    const v0, 0x40733333    # 3.8f

    mul-float v13, p2, v0

    sub-float v14, v7, v13

    const v0, 0x40866666    # 4.2f

    mul-float v0, v0, p2

    sub-float v15, v8, v0

    move-object/from16 v0, p0

    move v3, v14

    move v4, v15

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 126
    add-float/2addr v13, v7

    move v1, v14

    move v2, v15

    move v3, v13

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 127
    add-float v3, v7, v12

    move v1, v13

    move v4, v9

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 128
    const/high16 v0, 0x40200000    # 2.5f

    mul-float v9, p2, v0

    sub-float v3, v7, v9

    move-object/from16 v0, p0

    move v1, v3

    move v2, v11

    move v4, v15

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 129
    add-float/2addr v7, v9

    const v0, 0x3f4ccccd    # 0.8f

    mul-float v0, v0, p2

    add-float/2addr v8, v0

    move-object/from16 v0, p0

    move v1, v7

    move v3, v7

    move v4, v8

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 130
    move v2, v8

    move v3, v10

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 131
    return-void
.end method

.method public static drawHudButton(Landroid/graphics/Canvas;Landroid/graphics/RectF;IZLandroid/graphics/Paint;Landroid/graphics/Paint;)V
    .locals 21

    .line 56
    move-object/from16 v6, p0

    move-object/from16 v7, p1

    move-object/from16 v8, p4

    move-object/from16 v9, p5

    if-eqz v6, :cond_6

    if-eqz v7, :cond_6

    invoke-virtual/range {p1 .. p1}, Landroid/graphics/RectF;->isEmpty()Z

    move-result v0

    if-eqz v0, :cond_0

    goto/16 :goto_5

    .line 57
    :cond_0
    invoke-virtual/range {p1 .. p1}, Landroid/graphics/RectF;->width()F

    move-result v0

    const/high16 v1, 0x41a00000    # 20.0f

    div-float/2addr v0, v1

    const/high16 v10, 0x3f800000    # 1.0f

    invoke-static {v10, v0}, Ljava/lang/Math;->max(FF)F

    move-result v11

    .line 58
    iget v12, v7, Landroid/graphics/RectF;->left:F

    iget v13, v7, Landroid/graphics/RectF;->top:F

    iget v14, v7, Landroid/graphics/RectF;->right:F

    iget v15, v7, Landroid/graphics/RectF;->bottom:F

    .line 61
    sget-object v0, Landroid/graphics/Paint$Style;->FILL:Landroid/graphics/Paint$Style;

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 62
    const/high16 v0, -0x56000000

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 63
    const v0, 0x3f99999a    # 1.2f

    mul-float/2addr v0, v11

    add-float v1, v12, v0

    add-float v2, v13, v0

    add-float v3, v14, v0

    add-float v4, v15, v0

    move-object/from16 v0, p0

    move-object/from16 v5, p4

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 66
    const v0, -0xf4f1f0

    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 67
    move-object/from16 v0, p0

    move v1, v12

    move v2, v13

    move v3, v14

    move v4, v15

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 70
    sget-object v0, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 71
    const v0, 0x3f8ccccd    # 1.1f

    mul-float/2addr v0, v11

    invoke-static {v10, v0}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 72
    if-eqz p3, :cond_1

    const v0, -0x2748a4

    goto :goto_0

    :cond_1
    const v0, -0x949cb0

    :goto_0
    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 73
    const/high16 v0, 0x3f000000    # 0.5f

    mul-float/2addr v0, v11

    add-float v1, v12, v0

    add-float v2, v13, v0

    sub-float v3, v14, v0

    sub-float v4, v15, v0

    move-object/from16 v0, p0

    move-object/from16 v5, p5

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 76
    const v0, 0x3fe66666    # 1.8f

    mul-float/2addr v0, v11

    .line 77
    if-eqz p3, :cond_2

    const v1, -0xd5dbe9

    goto :goto_1

    :cond_2
    const v1, -0xe8e8eb

    :goto_1
    invoke-virtual {v8, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 78
    add-float v16, v12, v0

    add-float v17, v13, v0

    sub-float v18, v14, v0

    sub-float v19, v15, v0

    move-object/from16 v0, p0

    move/from16 v1, v16

    move/from16 v2, v17

    move/from16 v3, v18

    move/from16 v4, v19

    move-object/from16 v5, p4

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 79
    const v0, 0x3f666666    # 0.9f

    mul-float v5, v11, v0

    const v0, 0x3f4ccccd    # 0.8f

    invoke-static {v0, v5}, Ljava/lang/Math;->max(FF)F

    move-result v0

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 80
    const v0, -0xb2165

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 81
    move-object/from16 v0, p0

    move/from16 v3, v16

    move/from16 v20, v5

    move-object/from16 v5, p5

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 82
    move/from16 v3, v18

    move/from16 v4, v17

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 83
    const v0, -0x91b5e4

    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 84
    move-object/from16 v0, p0

    move/from16 v1, v18

    move/from16 v4, v19

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 85
    move/from16 v1, v16

    move/from16 v2, v19

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 88
    if-eqz p3, :cond_3

    const/16 v0, -0x1c66

    goto :goto_2

    :cond_3
    const v0, -0xa3a8b8

    :goto_2
    invoke-virtual {v8, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 89
    nop

    .line 90
    mul-float/2addr v10, v11

    add-float/2addr v12, v10

    add-float/2addr v13, v10

    add-float v16, v12, v20

    add-float v17, v13, v20

    move-object/from16 v0, p0

    move v1, v12

    move v2, v13

    move/from16 v3, v16

    move/from16 v4, v17

    move-object/from16 v5, p4

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 91
    sub-float/2addr v14, v10

    sub-float v18, v14, v20

    move/from16 v1, v18

    move v3, v14

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 92
    sub-float v10, v15, v10

    sub-float v13, v10, v20

    move v1, v12

    move v2, v13

    move/from16 v3, v16

    move v4, v10

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 93
    move/from16 v1, v18

    move v3, v14

    invoke-virtual/range {v0 .. v5}, Landroid/graphics/Canvas;->drawRect(FFFFLandroid/graphics/Paint;)V

    .line 95
    if-eqz p3, :cond_4

    const/16 v0, -0x1852

    goto :goto_3

    :cond_4
    const v0, -0x858b9e

    .line 96
    :goto_3
    invoke-virtual {v9, v0}, Landroid/graphics/Paint;->setColor(I)V

    .line 97
    if-nez p2, :cond_5

    invoke-static {v6, v7, v11, v9}, Lcom/ahsim/demulation/DuneSegaHud;->drawUnitsIcon(Landroid/graphics/Canvas;Landroid/graphics/RectF;FLandroid/graphics/Paint;)V

    goto :goto_4

    .line 98
    :cond_5
    invoke-static {v6, v7, v11, v9}, Lcom/ahsim/demulation/DuneSegaHud;->drawBaseIcon(Landroid/graphics/Canvas;Landroid/graphics/RectF;FLandroid/graphics/Paint;)V

    .line 99
    :goto_4
    return-void

    .line 56
    :cond_6
    :goto_5
    return-void
.end method

.method private static drawUnitsIcon(Landroid/graphics/Canvas;Landroid/graphics/RectF;FLandroid/graphics/Paint;)V
    .locals 8

    .line 102
    invoke-virtual {p1}, Landroid/graphics/RectF;->centerX()F

    move-result v0

    invoke-virtual {p1}, Landroid/graphics/RectF;->centerY()F

    move-result p1

    const/high16 v1, 0x3f000000    # 0.5f

    mul-float/2addr v1, p2

    add-float/2addr p1, v1

    .line 103
    sget-object v1, Landroid/graphics/Paint$Style;->STROKE:Landroid/graphics/Paint$Style;

    invoke-virtual {p3, v1}, Landroid/graphics/Paint;->setStyle(Landroid/graphics/Paint$Style;)V

    .line 104
    const v1, 0x3f933333    # 1.15f

    mul-float/2addr v1, p2

    const/high16 v2, 0x3f800000    # 1.0f

    invoke-static {v2, v1}, Ljava/lang/Math;->max(FF)F

    move-result v1

    invoke-virtual {p3, v1}, Landroid/graphics/Paint;->setStrokeWidth(F)V

    .line 105
    const/16 v1, -0x1852

    invoke-virtual {p3, v1}, Landroid/graphics/Paint;->setColor(I)V

    .line 106
    new-instance v1, Landroid/graphics/RectF;

    const v2, 0x40b33333    # 5.6f

    mul-float/2addr v2, p2

    sub-float v3, v0, v2

    const v4, 0x40266666    # 2.6f

    mul-float/2addr v4, p2

    sub-float v5, p1, v4

    const v6, 0x3f4ccccd    # 0.8f

    mul-float/2addr v6, p2

    sub-float v7, v0, v6

    add-float/2addr v4, p1

    invoke-direct {v1, v3, v5, v7, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 107
    new-instance v3, Landroid/graphics/RectF;

    add-float/2addr v6, v0

    add-float/2addr v2, v0

    invoke-direct {v3, v6, v5, v2, v4}, Landroid/graphics/RectF;-><init>(FFFF)V

    .line 108
    invoke-virtual {p0}, Landroid/graphics/Canvas;->save()I

    move-result v2

    .line 109
    const v4, 0x4059999a    # 3.4f

    mul-float/2addr v4, p2

    sub-float v5, v0, v4

    const/high16 v6, -0x3e100000    # -30.0f

    invoke-virtual {p0, v6, v5, p1}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 110
    invoke-virtual {p0, v1, p3}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 111
    invoke-virtual {p0, v2}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 112
    invoke-virtual {p0}, Landroid/graphics/Canvas;->save()I

    move-result v1

    .line 113
    add-float/2addr v4, v0

    invoke-virtual {p0, v6, v4, p1}, Landroid/graphics/Canvas;->rotate(FFF)V

    .line 114
    invoke-virtual {p0, v3, p3}, Landroid/graphics/Canvas;->drawOval(Landroid/graphics/RectF;Landroid/graphics/Paint;)V

    .line 115
    invoke-virtual {p0, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 116
    const v1, 0x3fe66666    # 1.8f

    mul-float/2addr v1, p2

    sub-float v3, v0, v1

    const v2, 0x3f99999a    # 1.2f

    mul-float/2addr p2, v2

    add-float v4, p1, p2

    add-float v5, v0, v1

    sub-float v6, p1, p2

    move-object v2, p0

    move-object v7, p3

    invoke-virtual/range {v2 .. v7}, Landroid/graphics/Canvas;->drawLine(FFFFLandroid/graphics/Paint;)V

    .line 117
    return-void
.end method

.method public static init(Landroid/content/Context;)V
    .locals 0

    return-void
.end method

.method public static typeface(Landroid/content/Context;)Landroid/graphics/Typeface;
    .locals 1

    sget-object v0, Landroid/graphics/Typeface;->MONOSPACE:Landroid/graphics/Typeface;

    sput-object v0, Lcom/ahsim/demulation/DuneSegaHud;->cachedTypeface:Landroid/graphics/Typeface;

    return-object v0
.end method
