.class public final synthetic Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda73;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Landroid/widget/LinearLayout;

.field public final synthetic f$1:Landroid/widget/Button;


# direct methods
.method public synthetic constructor <init>(Landroid/widget/LinearLayout;Landroid/widget/Button;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda73;->f$0:Landroid/widget/LinearLayout;

    iput-object p2, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda73;->f$1:Landroid/widget/Button;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 2

    .line 0
    iget-object v0, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda73;->f$0:Landroid/widget/LinearLayout;

    iget-object v1, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda73;->f$1:Landroid/widget/Button;

    invoke-static {v0, v1, p1}, Lcom/ahsim/demulation/LauncherActivity;->lambda$addRazorSessionControls$30(Landroid/widget/LinearLayout;Landroid/widget/Button;Landroid/view/View;)V

    return-void
.end method
