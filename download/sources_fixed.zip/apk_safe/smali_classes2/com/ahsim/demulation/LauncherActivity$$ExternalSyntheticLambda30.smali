.class public final synthetic Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda30;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/ahsim/demulation/LauncherActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/ahsim/demulation/LauncherActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda30;->f$0:Lcom/ahsim/demulation/LauncherActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/ahsim/demulation/LauncherActivity$$ExternalSyntheticLambda30;->f$0:Lcom/ahsim/demulation/LauncherActivity;

    invoke-static {v0, p1}, Lcom/ahsim/demulation/LauncherActivity;->$r8$lambda$LqKO_Sch1HD5C5MfeAaztFeMKNM(Lcom/ahsim/demulation/LauncherActivity;Landroid/view/View;)V

    return-void
.end method
