.class public final enum Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;
.super Ljava/lang/Enum;
.source "RomOriginalContentReadySchema.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ahsim/demulation/RomOriginalContentReadySchema;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "Kind"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

.field public static final enum EXACT_TEXT:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

.field public static final enum GAME_PARAMETER_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

.field public static final enum PRESENTATION_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

.field public static final enum PURE_NATIVE_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

.field public static final enum SCENARIO_WORLD_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;


# direct methods
.method private static synthetic $values()[Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;
    .locals 5

    .line 20
    sget-object v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->EXACT_TEXT:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    sget-object v1, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->PRESENTATION_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    sget-object v2, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->SCENARIO_WORLD_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    sget-object v3, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->GAME_PARAMETER_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    sget-object v4, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->PURE_NATIVE_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    filled-new-array {v0, v1, v2, v3, v4}, [Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 21
    new-instance v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    const-string v1, "EXACT_TEXT"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->EXACT_TEXT:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    .line 22
    new-instance v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    const-string v1, "PRESENTATION_DATA"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->PRESENTATION_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    .line 23
    new-instance v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    const-string v1, "SCENARIO_WORLD_DATA"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->SCENARIO_WORLD_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    .line 24
    new-instance v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    const-string v1, "GAME_PARAMETER_DATA"

    const/4 v2, 0x3

    invoke-direct {v0, v1, v2}, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->GAME_PARAMETER_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    .line 25
    new-instance v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    const-string v1, "PURE_NATIVE_DATA"

    const/4 v2, 0x4

    invoke-direct {v0, v1, v2}, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->PURE_NATIVE_DATA:Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    .line 20
    invoke-static {}, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->$values()[Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    move-result-object v0

    sput-object v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->$VALUES:[Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 20
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .line 20
    const-class v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    return-object v0
.end method

.method public static values()[Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;
    .locals 1

    .line 20
    sget-object v0, Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->$VALUES:[Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    invoke-virtual {v0}, [Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/ahsim/demulation/RomOriginalContentReadySchema$Kind;

    return-object v0
.end method
