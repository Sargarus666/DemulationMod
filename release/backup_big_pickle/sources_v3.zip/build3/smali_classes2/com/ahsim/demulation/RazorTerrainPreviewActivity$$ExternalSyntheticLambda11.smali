.class public final synthetic Lcom/ahsim/demulation/RazorTerrainPreviewActivity$$ExternalSyntheticLambda11;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Landroid/view/View$OnClickListener;


# instance fields
.field public final synthetic f$0:Lcom/ahsim/demulation/RazorTerrainPreviewActivity;


# direct methods
.method public synthetic constructor <init>(Lcom/ahsim/demulation/RazorTerrainPreviewActivity;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/ahsim/demulation/RazorTerrainPreviewActivity$$ExternalSyntheticLambda11;->f$0:Lcom/ahsim/demulation/RazorTerrainPreviewActivity;

    return-void
.end method


# virtual methods
.method public final onClick(Landroid/view/View;)V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/ahsim/demulation/RazorTerrainPreviewActivity$$ExternalSyntheticLambda11;->f$0:Lcom/ahsim/demulation/RazorTerrainPreviewActivity;

    invoke-static {v0, p1}, Lcom/ahsim/demulation/RazorTerrainPreviewActivity;->$r8$lambda$QF0Dkl2RNNlqlRMYGRE_jiGiG9E(Lcom/ahsim/demulation/RazorTerrainPreviewActivity;Landroid/view/View;)V

    return-void
.end method
