.class public final enum Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;
.super Ljava/lang/Enum;
.source "DuneHackR82cRazorStructureImpactAudit.java"


# annotations
.annotation system Ldalvik/annotation/EnclosingClass;
    value = Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit;
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x4019
    name = "OriginalCoreRoute"
.end annotation

.annotation system Ldalvik/annotation/Signature;
    value = {
        "Ljava/lang/Enum<",
        "Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;",
        ">;"
    }
.end annotation


# static fields
.field private static final synthetic $VALUES:[Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

.field public static final enum DEVIATOR_NOT_ORDINARY_BUILDING_HP_DAMAGE:Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

.field public static final enum ORDINARY_PROJECTILE_VIA_EXPLOSION:Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

.field public static final enum SONIC_DIRECT_STRUCTURE_DAMAGE:Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;


# direct methods
.method private static synthetic $values()[Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;
    .locals 3

    .line 35
    sget-object v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;->ORDINARY_PROJECTILE_VIA_EXPLOSION:Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    sget-object v1, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;->SONIC_DIRECT_STRUCTURE_DAMAGE:Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    sget-object v2, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;->DEVIATOR_NOT_ORDINARY_BUILDING_HP_DAMAGE:Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    filled-new-array {v0, v1, v2}, [Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    move-result-object v0

    return-object v0
.end method

.method static constructor <clinit>()V
    .locals 3

    .line 36
    new-instance v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    const-string v1, "ORDINARY_PROJECTILE_VIA_EXPLOSION"

    const/4 v2, 0x0

    invoke-direct {v0, v1, v2}, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;->ORDINARY_PROJECTILE_VIA_EXPLOSION:Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    .line 37
    new-instance v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    const-string v1, "SONIC_DIRECT_STRUCTURE_DAMAGE"

    const/4 v2, 0x1

    invoke-direct {v0, v1, v2}, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;->SONIC_DIRECT_STRUCTURE_DAMAGE:Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    .line 38
    new-instance v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    const-string v1, "DEVIATOR_NOT_ORDINARY_BUILDING_HP_DAMAGE"

    const/4 v2, 0x2

    invoke-direct {v0, v1, v2}, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;-><init>(Ljava/lang/String;I)V

    sput-object v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;->DEVIATOR_NOT_ORDINARY_BUILDING_HP_DAMAGE:Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    .line 35
    invoke-static {}, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;->$values()[Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    move-result-object v0

    sput-object v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;->$VALUES:[Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    return-void
.end method

.method private constructor <init>(Ljava/lang/String;I)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 35
    invoke-direct {p0, p1, p2}, Ljava/lang/Enum;-><init>(Ljava/lang/String;I)V

    return-void
.end method

.method public static valueOf(Ljava/lang/String;)Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;
    .locals 1
    .param p0, "name"    # Ljava/lang/String;

    .line 35
    const-class v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    invoke-static {v0, p0}, Ljava/lang/Enum;->valueOf(Ljava/lang/Class;Ljava/lang/String;)Ljava/lang/Enum;

    move-result-object v0

    check-cast v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    return-object v0
.end method

.method public static values()[Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;
    .locals 1

    .line 35
    sget-object v0, Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;->$VALUES:[Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    invoke-virtual {v0}, [Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;->clone()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, [Lcom/ahsim/demulation/DuneHackR82cRazorStructureImpactAudit$OriginalCoreRoute;

    return-object v0
.end method
