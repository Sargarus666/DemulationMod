.class public final synthetic Lcom/ahsim/demulation/MainActivity$$ExternalSyntheticLambda42;
.super Ljava/lang/Object;
.source "D8$$SyntheticClass"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public final synthetic f$0:Landroid/app/Dialog;


# direct methods
.method public synthetic constructor <init>(Landroid/app/Dialog;)V
    .locals 0

    .line 0
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    iput-object p1, p0, Lcom/ahsim/demulation/MainActivity$$ExternalSyntheticLambda42;->f$0:Landroid/app/Dialog;

    return-void
.end method


# virtual methods
.method public final run()V
    .locals 1

    .line 0
    iget-object v0, p0, Lcom/ahsim/demulation/MainActivity$$ExternalSyntheticLambda42;->f$0:Landroid/app/Dialog;

    invoke-static {v0}, Lcom/ahsim/demulation/MainActivity;->$r8$lambda$1masqMmnVK1_xRyeRxSpm2z91v4(Landroid/app/Dialog;)V

    return-void
.end method
